/*
 * File: SVC_Controller.c
 *
 * Code generated for Simulink model 'SVC_Controller'.
 *
 * Model version                  : 1.47
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Jun 25 06:10:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SVC_Controller.h"
#include "SVC_Controller_private.h"

/* Block signals (auto storage) */
B_SVC_Controller_T SVC_Controller_B;

/* Block states (auto storage) */
DW_SVC_Controller_T SVC_Controller_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_SVC_Controller_T SVC_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_SVC_Controller_T SVC_Controller_Y;

/* Real-time model */
RT_MODEL_SVC_Controller_T SVC_Controller_M_;
RT_MODEL_SVC_Controller_T *const SVC_Controller_M = &SVC_Controller_M_;
real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T bpIdx;

  /* Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  return (table[iLeft + 1U] - table[iLeft]) * frac + table[iLeft];
}

/*
 * Output and update for enable system:
 *    '<S8>/Subsystem - pi//2 delay'
 *    '<S14>/Subsystem - pi//2 delay'
 *    '<S20>/Subsystem - pi//2 delay'
 *    '<S26>/Subsystem - pi//2 delay'
 */
void SVC_Controlle_Subsystempi2delay(uint8_T rtu_Enable, const real_T
  rtu_alpha_beta[2], real_T rtu_wt, B_Subsystempi2delay_SVC_Contr_T *localB)
{
  /* Outputs for Enabled SubSystem: '<S8>/Subsystem - pi//2 delay' incorporates:
   *  EnablePort: '<S12>/Enable'
   */
  if (rtu_Enable > 0) {
    /* Fcn: '<S12>/Fcn' */
    localB->Fcn = rtu_alpha_beta[0] * sin(rtu_wt) - rtu_alpha_beta[1] * cos
      (rtu_wt);

    /* Fcn: '<S12>/Fcn1' */
    localB->Fcn1 = rtu_alpha_beta[0] * cos(rtu_wt) + rtu_alpha_beta[1] * sin
      (rtu_wt);
  }

  /* End of Outputs for SubSystem: '<S8>/Subsystem - pi//2 delay' */
}

/*
 * Output and update for enable system:
 *    '<S8>/Subsystem1'
 *    '<S14>/Subsystem1'
 *    '<S20>/Subsystem1'
 *    '<S26>/Subsystem1'
 */
void SVC_Controller_Subsystem1(uint8_T rtu_Enable, const real_T rtu_alpha_beta[2],
  real_T rtu_wt, B_Subsystem1_SVC_Controller_T *localB)
{
  /* Outputs for Enabled SubSystem: '<S8>/Subsystem1' incorporates:
   *  EnablePort: '<S13>/Enable'
   */
  if (rtu_Enable > 0) {
    /* Fcn: '<S13>/Fcn' */
    localB->Fcn = rtu_alpha_beta[0] * cos(rtu_wt) + rtu_alpha_beta[1] * sin
      (rtu_wt);

    /* Fcn: '<S13>/Fcn1' */
    localB->Fcn1 = -rtu_alpha_beta[0] * sin(rtu_wt) + rtu_alpha_beta[1] * cos
      (rtu_wt);
  }

  /* End of Outputs for SubSystem: '<S8>/Subsystem1' */
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  if (u1 == 0.0) {
    y = u0;
  } else if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf
                (u1))))) {
    y = (rtNaN);
  } else {
    tmp = u0 / u1;
    if (u1 <= floor(u1)) {
      y = u0 - floor(tmp) * u1;
    } else if (fabs(tmp - rt_roundd_snf(tmp)) <= DBL_EPSILON * fabs(tmp)) {
      y = 0.0;
    } else {
      y = (tmp - floor(tmp)) * u1;
    }
  }

  return y;
}

/* Model step function */
void SVC_Controller_step(void)
{
  int_T idxDelay;
  boolean_T rtb_Delay1;
  boolean_T rtb_Delay2;
  real_T rtb_MathFunction;
  real_T rtb_Gain1[3];
  real_T rtb_Sum;
  boolean_T rtb_LogicalOperator;
  real_T rtb_Switch_idx_1;
  real_T rtb_Switch_j_idx_0;
  real_T tmp;

  /* Delay: '<S1>/Delay1' */
  rtb_Delay1 = SVC_Controller_DW.Delay1_DSTATE[0];

  /* Outport: '<Root>/Tc1' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion'
   *  Delay: '<S1>/Delay1'
   */
  SVC_Controller_Y.Tc1 = SVC_Controller_DW.Delay1_DSTATE[0];

  /* Delay: '<S1>/Delay2' */
  rtb_Delay2 = SVC_Controller_DW.Delay2_DSTATE[0];

  /* Outport: '<Root>/Ta1' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion5'
   *  Delay: '<S1>/Delay2'
   */
  SVC_Controller_Y.Ta1 = SVC_Controller_DW.Delay2_DSTATE[0];

  /* Math: '<S2>/Math Function' incorporates:
   *  Constant: '<S2>/Constant2'
   *  DiscreteIntegrator: '<S2>/Discrete-Time Integrator'
   */
  rtb_MathFunction = rt_modd_snf(SVC_Controller_DW.DiscreteTimeIntegrator_DSTATE,
    6.2831853071795862);
  for (idxDelay = 0; idxDelay < 3; idxDelay++) {
    /* Gain: '<S27>/Gain1' incorporates:
     *  Gain: '<S27>/Gain3'
     *  Inport: '<Root>/ISa'
     *  Inport: '<Root>/ISb'
     *  Inport: '<Root>/ISc'
     */
    rtb_Gain1[idxDelay] = 0.66666666666666663 *
      (SVC_Controller_ConstP.pooled4[idxDelay + 6] * SVC_Controller_U.ISc +
       (SVC_Controller_ConstP.pooled4[idxDelay + 3] * SVC_Controller_U.ISb +
        SVC_Controller_ConstP.pooled4[idxDelay] * SVC_Controller_U.ISa));
  }

  /* Outputs for Enabled SubSystem: '<S26>/Subsystem1' */
  SVC_Controller_Subsystem1(SVC_Controller_ConstB.Compare, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystem1);

  /* End of Outputs for SubSystem: '<S26>/Subsystem1' */

  /* Outputs for Enabled SubSystem: '<S26>/Subsystem - pi//2 delay' */
  SVC_Controlle_Subsystempi2delay(SVC_Controller_ConstB.Compare_p, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystempi2delay);

  /* End of Outputs for SubSystem: '<S26>/Subsystem - pi//2 delay' */

  /* Switch: '<S26>/Switch' */
  if (SVC_Controller_ConstB.Compare != 0) {
    rtb_Switch_idx_1 = SVC_Controller_B.Subsystem1.Fcn1;
  } else {
    rtb_Switch_idx_1 = SVC_Controller_B.Subsystempi2delay.Fcn1;
  }

  /* End of Switch: '<S26>/Switch' */
  for (idxDelay = 0; idxDelay < 3; idxDelay++) {
    /* Gain: '<S15>/Gain1' incorporates:
     *  Gain: '<S15>/Gain3'
     *  Inport: '<Root>/Vab'
     *  Inport: '<Root>/Vbc'
     *  Inport: '<Root>/Vca'
     */
    rtb_Gain1[idxDelay] = 0.66666666666666663 *
      (SVC_Controller_ConstP.pooled4[idxDelay + 6] * SVC_Controller_U.Vca +
       (SVC_Controller_ConstP.pooled4[idxDelay + 3] * SVC_Controller_U.Vbc +
        SVC_Controller_ConstP.pooled4[idxDelay] * SVC_Controller_U.Vab));
  }

  /* Outputs for Enabled SubSystem: '<S14>/Subsystem1' */
  SVC_Controller_Subsystem1(SVC_Controller_ConstB.Compare_d, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystem1_f);

  /* End of Outputs for SubSystem: '<S14>/Subsystem1' */

  /* Outputs for Enabled SubSystem: '<S14>/Subsystem - pi//2 delay' */
  SVC_Controlle_Subsystempi2delay(SVC_Controller_ConstB.Compare_e, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystempi2delay_b);

  /* End of Outputs for SubSystem: '<S14>/Subsystem - pi//2 delay' */

  /* Switch: '<S14>/Switch' */
  if (SVC_Controller_ConstB.Compare_d != 0) {
    rtb_Switch_j_idx_0 = SVC_Controller_B.Subsystem1_f.Fcn;
  } else {
    rtb_Switch_j_idx_0 = SVC_Controller_B.Subsystempi2delay_b.Fcn;
  }

  /* End of Switch: '<S14>/Switch' */
  for (idxDelay = 0; idxDelay < 3; idxDelay++) {
    /* Gain: '<S21>/Gain1' incorporates:
     *  Gain: '<S21>/Gain3'
     *  Inport: '<Root>/ITCRa'
     *  Inport: '<Root>/ITCRb'
     *  Inport: '<Root>/ITCRc'
     */
    rtb_Gain1[idxDelay] = 0.66666666666666663 *
      (SVC_Controller_ConstP.pooled4[idxDelay + 6] * SVC_Controller_U.ITCRc +
       (SVC_Controller_ConstP.pooled4[idxDelay + 3] * SVC_Controller_U.ITCRb +
        SVC_Controller_ConstP.pooled4[idxDelay] * SVC_Controller_U.ITCRa));
  }

  /* Outputs for Enabled SubSystem: '<S20>/Subsystem1' */
  SVC_Controller_Subsystem1(SVC_Controller_ConstB.Compare_j, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystem1_fj);

  /* End of Outputs for SubSystem: '<S20>/Subsystem1' */

  /* Outputs for Enabled SubSystem: '<S20>/Subsystem - pi//2 delay' */
  SVC_Controlle_Subsystempi2delay(SVC_Controller_ConstB.Compare_g, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystempi2delay_d);

  /* End of Outputs for SubSystem: '<S20>/Subsystem - pi//2 delay' */

  /* Sum: '<Root>/Sum' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<Root>/Gain'
   */
  rtb_Sum = -0.03236245954692557 * rtb_Switch_j_idx_0 - 10.0;

  /* Switch: '<S20>/Switch' */
  if (SVC_Controller_ConstB.Compare_j != 0) {
    tmp = SVC_Controller_B.Subsystem1_fj.Fcn1;
  } else {
    tmp = SVC_Controller_B.Subsystempi2delay_d.Fcn1;
  }

  /* End of Switch: '<S20>/Switch' */

  /* Sum: '<Root>/Sum3' incorporates:
   *  DiscreteIntegrator: '<Root>/Discrete-Time Integrator'
   *  Gain: '<Root>/Gain2'
   *  Product: '<Root>/Divide'
   *  Product: '<Root>/Divide1'
   *  Sum: '<Root>/Sum1'
   *  Sum: '<Root>/Sum2'
   */
  rtb_Switch_idx_1 = ((0.5 * rtb_Sum +
                       SVC_Controller_DW.DiscreteTimeIntegrator_DSTATE_k) + tmp /
                      rtb_Switch_j_idx_0) - rtb_Switch_idx_1 /
    rtb_Switch_j_idx_0;

  /* Saturate: '<Root>/Saturation' */
  if (rtb_Switch_idx_1 > 10.0) {
    rtb_Switch_idx_1 = 10.0;
  } else {
    if (rtb_Switch_idx_1 < -10.0) {
      rtb_Switch_idx_1 = -10.0;
    }
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Gain: '<S1>/Gain' incorporates:
   *  Lookup_n-D: '<Root>/1-D Lookup Table'
   */
  rtb_Switch_idx_1 = 0.017453292519943295 * look1_binlxpw(rtb_Switch_idx_1,
    SVC_Controller_ConstP.uDLookupTable_bp01Data,
    SVC_Controller_ConstP.uDLookupTable_tableData, 20U);

  /* Logic: '<S1>/Logical Operator' incorporates:
   *  Constant: '<S1>/Constant'
   *  RelationalOperator: '<S1>/Relational Operator'
   *  RelationalOperator: '<S1>/Relational Operator1'
   *  Sum: '<S1>/Sum'
   */
  rtb_LogicalOperator = ((rtb_MathFunction >= rtb_Switch_idx_1) &&
    (rtb_MathFunction <= rtb_Switch_idx_1 + 1.0471975511965976));

  /* Outport: '<Root>/Tb1' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion3'
   */
  SVC_Controller_Y.Tb1 = rtb_LogicalOperator;

  /* Outport: '<Root>/Tc2' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion1'
   *  Delay: '<S1>/Delay3'
   */
  SVC_Controller_Y.Tc2 = SVC_Controller_DW.Delay3_DSTATE[0];

  /* Outport: '<Root>/Ta2' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion4'
   *  Delay: '<S1>/Delay4'
   */
  SVC_Controller_Y.Ta2 = SVC_Controller_DW.Delay4_DSTATE[0];

  /* Outport: '<Root>/Tb2' incorporates:
   *  DataTypeConversion: '<S1>/Data Type Conversion2'
   *  Delay: '<S1>/Delay'
   */
  SVC_Controller_Y.Tb2 = SVC_Controller_DW.Delay_DSTATE[0];
  for (idxDelay = 0; idxDelay < 3; idxDelay++) {
    /* Gain: '<S9>/Gain1' incorporates:
     *  Gain: '<S9>/Gain3'
     *  Inport: '<Root>/Vab'
     *  Inport: '<Root>/Vbc'
     *  Inport: '<Root>/Vca'
     */
    rtb_Gain1[idxDelay] = 0.66666666666666663 *
      (SVC_Controller_ConstP.pooled4[idxDelay + 6] * SVC_Controller_U.Vca +
       (SVC_Controller_ConstP.pooled4[idxDelay + 3] * SVC_Controller_U.Vbc +
        SVC_Controller_ConstP.pooled4[idxDelay] * SVC_Controller_U.Vab));
  }

  /* Outputs for Enabled SubSystem: '<S8>/Subsystem1' */
  SVC_Controller_Subsystem1(SVC_Controller_ConstB.Compare_j2, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystem1_a);

  /* End of Outputs for SubSystem: '<S8>/Subsystem1' */

  /* Outputs for Enabled SubSystem: '<S8>/Subsystem - pi//2 delay' */
  SVC_Controlle_Subsystempi2delay(SVC_Controller_ConstB.Compare_gg, &rtb_Gain1[0],
    rtb_MathFunction, &SVC_Controller_B.Subsystempi2delay_n);

  /* End of Outputs for SubSystem: '<S8>/Subsystem - pi//2 delay' */

  /* Switch: '<S8>/Switch' */
  if (SVC_Controller_ConstB.Compare_j2 != 0) {
    tmp = SVC_Controller_B.Subsystem1_a.Fcn1;
  } else {
    tmp = SVC_Controller_B.Subsystempi2delay_n.Fcn1;
  }

  /* End of Switch: '<S8>/Switch' */

  /* Update for Delay: '<S1>/Delay1' */
  for (idxDelay = 0; idxDelay < 666; idxDelay++) {
    SVC_Controller_DW.Delay1_DSTATE[idxDelay] =
      SVC_Controller_DW.Delay1_DSTATE[idxDelay + 1];
  }

  SVC_Controller_DW.Delay1_DSTATE[666] = rtb_LogicalOperator;

  /* End of Update for Delay: '<S1>/Delay1' */

  /* Update for Delay: '<S1>/Delay2' */
  for (idxDelay = 0; idxDelay < 1332; idxDelay++) {
    SVC_Controller_DW.Delay2_DSTATE[idxDelay] =
      SVC_Controller_DW.Delay2_DSTATE[idxDelay + 1];
  }

  SVC_Controller_DW.Delay2_DSTATE[1332] = rtb_LogicalOperator;

  /* End of Update for Delay: '<S1>/Delay2' */

  /* Update for DiscreteIntegrator: '<S2>/Discrete-Time Integrator' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S2>/Constant1'
   *  DiscreteIntegrator: '<S6>/Integrator'
   *  Gain: '<S6>/Proportional Gain'
   *  Sum: '<S2>/Sum'
   *  Sum: '<S2>/Sum1'
   *  Sum: '<S6>/Sum'
   */
  SVC_Controller_DW.DiscreteTimeIntegrator_DSTATE += (((0.0 - tmp) * 500.0 +
    SVC_Controller_DW.Integrator_DSTATE) + 314.15926535897933) * 1.0E-5;

  /* Update for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
  SVC_Controller_DW.DiscreteTimeIntegrator_DSTATE_k += 1.0E-5 * rtb_Sum;
  for (idxDelay = 0; idxDelay < 999; idxDelay++) {
    /* Update for Delay: '<S1>/Delay3' */
    SVC_Controller_DW.Delay3_DSTATE[idxDelay] =
      SVC_Controller_DW.Delay3_DSTATE[idxDelay + 1];

    /* Update for Delay: '<S1>/Delay4' */
    SVC_Controller_DW.Delay4_DSTATE[idxDelay] =
      SVC_Controller_DW.Delay4_DSTATE[idxDelay + 1];

    /* Update for Delay: '<S1>/Delay' */
    SVC_Controller_DW.Delay_DSTATE[idxDelay] =
      SVC_Controller_DW.Delay_DSTATE[idxDelay + 1];
  }

  /* Update for Delay: '<S1>/Delay3' */
  SVC_Controller_DW.Delay3_DSTATE[999] = rtb_Delay1;

  /* Update for Delay: '<S1>/Delay4' */
  SVC_Controller_DW.Delay4_DSTATE[999] = rtb_Delay2;

  /* Update for Delay: '<S1>/Delay' */
  SVC_Controller_DW.Delay_DSTATE[999] = rtb_LogicalOperator;

  /* Update for DiscreteIntegrator: '<S6>/Integrator' incorporates:
   *  Constant: '<S2>/Constant'
   *  Gain: '<S6>/Integral Gain'
   *  Sum: '<S2>/Sum'
   */
  SVC_Controller_DW.Integrator_DSTATE += (0.0 - tmp) * 10.0 * 1.0E-5;
}

/* Model initialize function */
void SVC_Controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(SVC_Controller_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &SVC_Controller_B), 0,
                sizeof(B_SVC_Controller_T));

  /* states (dwork) */
  (void) memset((void *)&SVC_Controller_DW, 0,
                sizeof(DW_SVC_Controller_T));

  /* external inputs */
  (void)memset((void *)&SVC_Controller_U, 0, sizeof(ExtU_SVC_Controller_T));

  /* external outputs */
  (void) memset((void *)&SVC_Controller_Y, 0,
                sizeof(ExtY_SVC_Controller_T));
}

/* Model terminate function */
void SVC_Controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
