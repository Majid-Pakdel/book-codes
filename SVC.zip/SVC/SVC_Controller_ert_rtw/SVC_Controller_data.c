/*
 * File: SVC_Controller_data.c
 *
 * Code generated for Simulink model 'SVC_Controller'.
 *
 * Model version                  : 1.47
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Jun 25 06:10:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SVC_Controller.h"
#include "SVC_Controller_private.h"

/* Invariant block signals (auto storage) */
const ConstB_SVC_Controller_T SVC_Controller_ConstB = {
  0U,                                  /* '<S28>/Compare' */
  1U,                                  /* '<S29>/Compare' */
  0U,                                  /* '<S16>/Compare' */
  1U,                                  /* '<S17>/Compare' */
  0U,                                  /* '<S22>/Compare' */
  1U,                                  /* '<S23>/Compare' */
  0U,                                  /* '<S10>/Compare' */
  1U                                   /* '<S11>/Compare' */
};

/* Constant parameters (auto storage) */
const ConstP_SVC_Controller_T SVC_Controller_ConstP = {
  /* Pooled Parameter (Expression: [ 1   -1/2   -1/2; 0   sqrt(3)/2   -sqrt(3)/2; 1/2  1/2  1/2 ] )
   * Referenced by:
   *   '<S15>/Gain3'
   *   '<S21>/Gain3'
   *   '<S27>/Gain3'
   *   '<S9>/Gain3'
   */
  { 1.0, 0.0, 0.5, -0.5, 0.8660254037844386, 0.5, -0.5, -0.8660254037844386, 0.5
  },

  /* Expression: ([180 160 140 137 134 131 128 125 120 115 110 107 104 102 100 99 98 96 94 92 90])
   * Referenced by: '<Root>/1-D Lookup Table'
   */
  { 180.0, 160.0, 140.0, 137.0, 134.0, 131.0, 128.0, 125.0, 120.0, 115.0, 110.0,
    107.0, 104.0, 102.0, 100.0, 99.0, 98.0, 96.0, 94.0, 92.0, 90.0 },

  /* Expression: [-10 -9 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10]
   * Referenced by: '<Root>/1-D Lookup Table'
   */
  { -10.0, -9.0, -8.0, -7.0, -6.0, -5.0, -4.0, -3.0, -2.0, -1.0, 0.0, 1.0, 2.0,
    3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
