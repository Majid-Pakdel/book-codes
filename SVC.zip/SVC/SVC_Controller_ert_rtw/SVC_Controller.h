/*
 * File: SVC_Controller.h
 *
 * Code generated for Simulink model 'SVC_Controller'.
 *
 * Model version                  : 1.47
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Jun 25 06:10:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SVC_Controller_h_
#define RTW_HEADER_SVC_Controller_h_
#include <float.h>
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef SVC_Controller_COMMON_INCLUDES_
# define SVC_Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* SVC_Controller_COMMON_INCLUDES_ */

#include "SVC_Controller_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<S8>/Subsystem - pi//2 delay' */
typedef struct {
  real_T Fcn;                          /* '<S12>/Fcn' */
  real_T Fcn1;                         /* '<S12>/Fcn1' */
} B_Subsystempi2delay_SVC_Contr_T;

/* Block signals for system '<S8>/Subsystem1' */
typedef struct {
  real_T Fcn;                          /* '<S13>/Fcn' */
  real_T Fcn1;                         /* '<S13>/Fcn1' */
} B_Subsystem1_SVC_Controller_T;

/* Block signals (auto storage) */
typedef struct {
  B_Subsystem1_SVC_Controller_T Subsystem1;/* '<S26>/Subsystem1' */
  B_Subsystempi2delay_SVC_Contr_T Subsystempi2delay;/* '<S26>/Subsystem - pi//2 delay' */
  B_Subsystem1_SVC_Controller_T Subsystem1_fj;/* '<S20>/Subsystem1' */
  B_Subsystempi2delay_SVC_Contr_T Subsystempi2delay_d;/* '<S20>/Subsystem - pi//2 delay' */
  B_Subsystem1_SVC_Controller_T Subsystem1_f;/* '<S14>/Subsystem1' */
  B_Subsystempi2delay_SVC_Contr_T Subsystempi2delay_b;/* '<S14>/Subsystem - pi//2 delay' */
  B_Subsystem1_SVC_Controller_T Subsystem1_a;/* '<S8>/Subsystem1' */
  B_Subsystempi2delay_SVC_Contr_T Subsystempi2delay_n;/* '<S8>/Subsystem - pi//2 delay' */
} B_SVC_Controller_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S2>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_k;/* '<Root>/Discrete-Time Integrator' */
  real_T Integrator_DSTATE;            /* '<S6>/Integrator' */
  boolean_T Delay1_DSTATE[667];        /* '<S1>/Delay1' */
  boolean_T Delay2_DSTATE[1333];       /* '<S1>/Delay2' */
  boolean_T Delay3_DSTATE[1000];       /* '<S1>/Delay3' */
  boolean_T Delay4_DSTATE[1000];       /* '<S1>/Delay4' */
  boolean_T Delay_DSTATE[1000];        /* '<S1>/Delay' */
} DW_SVC_Controller_T;

/* Invariant block signals (auto storage) */
typedef struct {
  const uint8_T Compare;               /* '<S28>/Compare' */
  const uint8_T Compare_p;             /* '<S29>/Compare' */
  const uint8_T Compare_d;             /* '<S16>/Compare' */
  const uint8_T Compare_e;             /* '<S17>/Compare' */
  const uint8_T Compare_j;             /* '<S22>/Compare' */
  const uint8_T Compare_g;             /* '<S23>/Compare' */
  const uint8_T Compare_j2;            /* '<S10>/Compare' */
  const uint8_T Compare_gg;            /* '<S11>/Compare' */
} ConstB_SVC_Controller_T;

/* Constant parameters (auto storage) */
typedef struct {
  /* Pooled Parameter (Expression: [ 1   -1/2   -1/2; 0   sqrt(3)/2   -sqrt(3)/2; 1/2  1/2  1/2 ] )
   * Referenced by:
   *   '<S15>/Gain3'
   *   '<S21>/Gain3'
   *   '<S27>/Gain3'
   *   '<S9>/Gain3'
   */
  real_T pooled4[9];

  /* Expression: ([180 160 140 137 134 131 128 125 120 115 110 107 104 102 100 99 98 96 94 92 90])
   * Referenced by: '<Root>/1-D Lookup Table'
   */
  real_T uDLookupTable_tableData[21];

  /* Expression: [-10 -9 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10]
   * Referenced by: '<Root>/1-D Lookup Table'
   */
  real_T uDLookupTable_bp01Data[21];
} ConstP_SVC_Controller_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Vab;                          /* '<Root>/Vab' */
  real_T Vbc;                          /* '<Root>/Vbc' */
  real_T Vca;                          /* '<Root>/Vca' */
  real_T ITCRa;                        /* '<Root>/ITCRa' */
  real_T ITCRb;                        /* '<Root>/ITCRb' */
  real_T ITCRc;                        /* '<Root>/ITCRc' */
  real_T ISa;                          /* '<Root>/ISa' */
  real_T ISb;                          /* '<Root>/ISb' */
  real_T ISc;                          /* '<Root>/ISc' */
} ExtU_SVC_Controller_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T Tc1;                          /* '<Root>/Tc1' */
  real_T Ta1;                          /* '<Root>/Ta1' */
  real_T Tb1;                          /* '<Root>/Tb1' */
  real_T Tc2;                          /* '<Root>/Tc2' */
  real_T Ta2;                          /* '<Root>/Ta2' */
  real_T Tb2;                          /* '<Root>/Tb2' */
} ExtY_SVC_Controller_T;

/* Real-time Model Data Structure */
struct tag_RTM_SVC_Controller_T {
  const char_T * volatile errorStatus;
};

/* Block signals (auto storage) */
extern B_SVC_Controller_T SVC_Controller_B;

/* Block states (auto storage) */
extern DW_SVC_Controller_T SVC_Controller_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_SVC_Controller_T SVC_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_SVC_Controller_T SVC_Controller_Y;
extern const ConstB_SVC_Controller_T SVC_Controller_ConstB;/* constant block i/o */

/* Constant parameters (auto storage) */
extern const ConstP_SVC_Controller_T SVC_Controller_ConstP;

/* Model entry point functions */
extern void SVC_Controller_initialize(void);
extern void SVC_Controller_step(void);
extern void SVC_Controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_SVC_Controller_T *const SVC_Controller_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Scope10' : Unused code path elimination
 * Block '<Root>/Scope1' : Unused code path elimination
 * Block '<Root>/Scope13' : Unused code path elimination
 * Block '<Root>/Scope2' : Unused code path elimination
 * Block '<Root>/Scope5' : Unused code path elimination
 * Block '<Root>/Scope6' : Unused code path elimination
 * Block '<Root>/Scope7' : Unused code path elimination
 * Block '<Root>/Scope9' : Unused code path elimination
 * Block '<S1>/Rate Transition' : Eliminated since input and output rates are identical
 * Block '<Root>/Gain1' : Eliminated nontunable gain of 1
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SVC_Controller'
 * '<S1>'   : 'SVC_Controller/6pulse_gen'
 * '<S2>'   : 'SVC_Controller/PLL'
 * '<S3>'   : 'SVC_Controller/abc to dq0'
 * '<S4>'   : 'SVC_Controller/abc to dq1'
 * '<S5>'   : 'SVC_Controller/abc to dq2'
 * '<S6>'   : 'SVC_Controller/PLL/Discrete PID Controller'
 * '<S7>'   : 'SVC_Controller/PLL/abc to dq0'
 * '<S8>'   : 'SVC_Controller/PLL/abc to dq0/Alpha-Beta-Zero to dq0'
 * '<S9>'   : 'SVC_Controller/PLL/abc to dq0/abc to Alpha-Beta-Zero'
 * '<S10>'  : 'SVC_Controller/PLL/abc to dq0/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S11>'  : 'SVC_Controller/PLL/abc to dq0/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S12>'  : 'SVC_Controller/PLL/abc to dq0/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S13>'  : 'SVC_Controller/PLL/abc to dq0/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S14>'  : 'SVC_Controller/abc to dq0/Alpha-Beta-Zero to dq0'
 * '<S15>'  : 'SVC_Controller/abc to dq0/abc to Alpha-Beta-Zero'
 * '<S16>'  : 'SVC_Controller/abc to dq0/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S17>'  : 'SVC_Controller/abc to dq0/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S18>'  : 'SVC_Controller/abc to dq0/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S19>'  : 'SVC_Controller/abc to dq0/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S20>'  : 'SVC_Controller/abc to dq1/Alpha-Beta-Zero to dq0'
 * '<S21>'  : 'SVC_Controller/abc to dq1/abc to Alpha-Beta-Zero'
 * '<S22>'  : 'SVC_Controller/abc to dq1/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S23>'  : 'SVC_Controller/abc to dq1/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S24>'  : 'SVC_Controller/abc to dq1/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S25>'  : 'SVC_Controller/abc to dq1/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S26>'  : 'SVC_Controller/abc to dq2/Alpha-Beta-Zero to dq0'
 * '<S27>'  : 'SVC_Controller/abc to dq2/abc to Alpha-Beta-Zero'
 * '<S28>'  : 'SVC_Controller/abc to dq2/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S29>'  : 'SVC_Controller/abc to dq2/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S30>'  : 'SVC_Controller/abc to dq2/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S31>'  : 'SVC_Controller/abc to dq2/Alpha-Beta-Zero to dq0/Subsystem1'
 */
#endif                                 /* RTW_HEADER_SVC_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
