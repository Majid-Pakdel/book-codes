/*
 * File: DVR_Controller.c
 *
 * Code generated for Simulink model 'DVR_Controller'.
 *
 * Model version                  : 1.23
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Jul 09 11:13:45 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "DVR_Controller.h"
#include "DVR_Controller_private.h"

/* Block signals (auto storage) */
B_DVR_Controller_T DVR_Controller_B;

/* Continuous states */
X_DVR_Controller_T DVR_Controller_X;

/* Block states (auto storage) */
DW_DVR_Controller_T DVR_Controller_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_DVR_Controller_T DVR_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_DVR_Controller_T DVR_Controller_Y;

/* Real-time model */
RT_MODEL_DVR_Controller_T DVR_Controller_M_;
RT_MODEL_DVR_Controller_T *const DVR_Controller_M = &DVR_Controller_M_;

/* Lookup 1D UtilityLookUpEven_real_T_real_T */
void LookUpEven_real_T_real_T(real_T *pY, const real_T *pYData, real_T u, real_T
  valueLo, uint32_T iHi, real_T uSpacing)
{
  if (u <= valueLo ) {
    (*pY) = (*pYData);
  } else {
    real_T uAdjusted = u - valueLo;
    real_T tmpIdxLeft = uAdjusted / uSpacing;
    uint32_T iLeft = (uint32_T)tmpIdxLeft;
    if ((tmpIdxLeft >= 4294967296.0) || (iLeft >= iHi) ) {
      (*pY) = pYData[iHi];
    } else {
      {
        real_T lambda;

        {
          real_T num = (real_T)uAdjusted - ( iLeft * uSpacing );
          lambda = num / uSpacing;
        }

        {
          real_T yLeftCast;
          real_T yRghtCast;
          yLeftCast = pYData[iLeft];
          yRghtCast = pYData[((iLeft)+1)];
          yLeftCast += lambda * ( yRghtCast - yLeftCast );
          (*pY) = yLeftCast;
        }
      }
    }
  }
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  DVR_Controller_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  DVR_Controller_step();
  DVR_Controller_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  DVR_Controller_step();
  DVR_Controller_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/*
 * Output and update for action system:
 *    '<S14>/Action: One'
 *    '<S60>/Action: One'
 *    '<S106>/Action: One'
 */
void DVR_Controller_ActionOne(real_T *rty_Out1)
{
  /* SignalConversion: '<S27>/OutportBufferForOut1' incorporates:
   *  Constant: '<S27>/One'
   */
  *rty_Out1 = 1.0;
}

/*
 * Output and update for action system:
 *    '<S29>/If Action Subsystem'
 *    '<S30>/If Action Subsystem'
 *    '<S31>/If Action Subsystem'
 *    '<S44>/If Action Subsystem'
 *    '<S45>/If Action Subsystem'
 *    '<S46>/If Action Subsystem'
 *    '<S75>/If Action Subsystem'
 *    '<S76>/If Action Subsystem'
 *    '<S77>/If Action Subsystem'
 *    '<S90>/If Action Subsystem'
 *    ...
 */
void DVR_Controlle_IfActionSubsystem(real_T *rty_Out1)
{
  /* SignalConversion: '<S32>/OutportBufferForOut1' incorporates:
   *  Constant: '<S32>/0'
   */
  *rty_Out1 = 0.0;
}

/*
 * Output and update for action system:
 *    '<S29>/If Action Subsystem1'
 *    '<S30>/If Action Subsystem1'
 *    '<S31>/If Action Subsystem1'
 *    '<S44>/If Action Subsystem1'
 *    '<S45>/If Action Subsystem1'
 *    '<S46>/If Action Subsystem1'
 *    '<S75>/If Action Subsystem1'
 *    '<S76>/If Action Subsystem1'
 *    '<S77>/If Action Subsystem1'
 *    '<S90>/If Action Subsystem1'
 *    ...
 */
void DVR_Controll_IfActionSubsystem1(real_T *rty_Out1)
{
  /* SignalConversion: '<S33>/OutportBufferForOut1' incorporates:
   *  Constant: '<S33>/0'
   */
  *rty_Out1 = 1.0;
}

/*
 * Output and update for action system:
 *    '<S29>/If Action Subsystem3'
 *    '<S30>/If Action Subsystem3'
 *    '<S31>/If Action Subsystem3'
 *    '<S44>/If Action Subsystem3'
 *    '<S45>/If Action Subsystem3'
 *    '<S46>/If Action Subsystem3'
 *    '<S75>/If Action Subsystem3'
 *    '<S76>/If Action Subsystem3'
 *    '<S77>/If Action Subsystem3'
 *    '<S90>/If Action Subsystem3'
 *    ...
 */
void DVR_Controll_IfActionSubsystem3(real_T rtu_x, real_T *rty_Out1, real_T
  rtp_a, real_T rtp_b)
{
  /* Product: '<S35>/Product ab (trimf)' incorporates:
   *  Constant: '<S35>/a'
   *  Constant: '<S35>/b'
   *  Sum: '<S35>/Sum'
   *  Sum: '<S35>/Sum1'
   */
  *rty_Out1 = (rtu_x - rtp_a) / (rtp_b - rtp_a);
}

/*
 * Output and update for action system:
 *    '<S29>/If Action Subsystem2'
 *    '<S30>/If Action Subsystem2'
 *    '<S31>/If Action Subsystem2'
 *    '<S44>/If Action Subsystem2'
 *    '<S45>/If Action Subsystem2'
 *    '<S46>/If Action Subsystem2'
 *    '<S75>/If Action Subsystem2'
 *    '<S76>/If Action Subsystem2'
 *    '<S77>/If Action Subsystem2'
 *    '<S90>/If Action Subsystem2'
 *    ...
 */
void DVR_Controll_IfActionSubsystem2(real_T rtu_x, real_T *rty_Out1, real_T
  rtp_b, real_T rtp_c)
{
  /* Product: '<S34>/Product cd (trimf)' incorporates:
   *  Constant: '<S34>/b'
   *  Constant: '<S34>/c'
   *  Sum: '<S34>/Sum2'
   *  Sum: '<S34>/Sum3'
   */
  *rty_Out1 = 1.0 / (rtp_c - rtp_b) * (rtp_c - rtu_x);
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tr;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = (rtNaN);
  } else if ((u1 != 0.0) && (u1 != trunc(u1))) {
    tr = u0 / u1;
    if (fabs(tr - rt_roundd_snf(tr)) <= DBL_EPSILON * fabs(tr)) {
      y = 0.0;
    } else {
      y = fmod(u0, u1);
    }
  } else {
    y = fmod(u0, u1);
  }

  return y;
}

/* Model step function */
void DVR_Controller_step(void)
{
  /* local block i/o variables */
  real_T rtb_Merge;
  real_T rtb_Merge_m;
  real_T rtb_Merge_j;
  real_T rtb_Merge_o;
  real_T rtb_Merge_c;
  real_T rtb_Merge_o2;
  real_T rtb_Merge_e;
  real_T rtb_Merge_b;
  real_T rtb_Merge_me;
  real_T rtb_Merge_p;
  real_T rtb_Merge_n;
  real_T rtb_Merge_h;
  real_T rtb_Merge_d;
  real_T rtb_Merge_b4;
  real_T rtb_Merge_jq;
  real_T rtb_Merge_mi;
  real_T rtb_Merge_k;
  real_T rtb_Merge_mn;
  real_T rtb_Merge_ht;
  real_T rtb_Merge_oc;
  real_T rtb_Merge_htk;
  real_T rtb_uib1;
  real_T rtb_LookupTable;
  real_T rtb_Relay;
  real_T rtb_Relay1;
  real_T rtb_uib1_e;
  real_T rtb_LookupTable_j;
  real_T rtb_Relay2;
  real_T rtb_Relay3;
  real_T rtb_uib1_g;
  real_T rtb_LookupTable_c;
  real_T rtb_Relay4;
  real_T rtb_Relay5;
  real_T rtb_Sum_n;
  real_T rtb_UnitDelay[3];
  int8_T rtAction;
  real_T rtb_Weighting;
  real_T rtb_Weighting_cd;
  real_T rtb_Weighting_f;
  real_T rtb_Weighting_i;
  real_T rtb_Weighting_l0;
  real_T rtb_Weighting_p;
  real_T rtb_Weighting_a;
  real_T rtb_MathFunction_f;
  real_T rtb_MathFunction_g;
  real_T rtb_AggMethod1[101];
  real_T rtb_Sum1;
  real_T rtb_Sum2;
  real_T rtb_Sum1_j;
  int32_T i;
  if (rtmIsMajorTimeStep(DVR_Controller_M)) {
    /* set solver stop time */
    if (!(DVR_Controller_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&DVR_Controller_M->solverInfo,
                            ((DVR_Controller_M->Timing.clockTickH0 + 1) *
        DVR_Controller_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&DVR_Controller_M->solverInfo,
                            ((DVR_Controller_M->Timing.clockTick0 + 1) *
        DVR_Controller_M->Timing.stepSize0 +
        DVR_Controller_M->Timing.clockTickH0 *
        DVR_Controller_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(DVR_Controller_M)) {
    DVR_Controller_M->Timing.t[0] = rtsiGetT(&DVR_Controller_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(DVR_Controller_M)) {
    /* Outport: '<Root>/GaH' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GaH = DVR_Controller_DW.UnitDelay_DSTATE[0];

    /* Outport: '<Root>/GaL' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GaL = DVR_Controller_DW.UnitDelay_DSTATE[1];

    /* Outport: '<Root>/GbH' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GbH = DVR_Controller_DW.UnitDelay_DSTATE[2];

    /* Outport: '<Root>/GbL' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GbL = DVR_Controller_DW.UnitDelay_DSTATE[3];

    /* Outport: '<Root>/GcH' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GcH = DVR_Controller_DW.UnitDelay_DSTATE[4];

    /* Outport: '<Root>/GcL' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    DVR_Controller_Y.GcL = DVR_Controller_DW.UnitDelay_DSTATE[5];

    /* If: '<S29>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[0] < -1.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[0] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S29>/If Action Subsystem' incorporates:
       *  ActionPort: '<S32>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge);

      /* End of Outputs for SubSystem: '<S29>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S29>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S33>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge);

      /* End of Outputs for SubSystem: '<S29>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S29>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S35>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S29>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S29>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S34>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S29>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S29>/If' */

    /* If: '<S44>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[0] < -1.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[0] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_p = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_p;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S44>/If Action Subsystem' incorporates:
       *  ActionPort: '<S47>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S44>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S44>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S48>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_m);

      /* End of Outputs for SubSystem: '<S44>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S44>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S50>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_m, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S44>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S44>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S49>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_m, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S44>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S44>/If' */

    /* Product: '<S15>/Weighting' incorporates:
     *  MinMax: '<S15>/andorMethod'
     */
    rtb_Weighting = fmin(rtb_Merge, rtb_Merge_m);

    /* If: '<S45>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[0] < -0.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[0] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_o = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_o;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S45>/If Action Subsystem' incorporates:
       *  ActionPort: '<S51>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S45>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S45>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S52>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_j);

      /* End of Outputs for SubSystem: '<S45>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S45>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S54>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_j, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S45>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S45>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S53>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_j, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S45>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S45>/If' */

    /* Product: '<S16>/Weighting' incorporates:
     *  MinMax: '<S16>/andorMethod'
     */
    rtb_Weighting_cd = fmin(rtb_Merge, rtb_Merge_j);

    /* If: '<S46>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[0] < 0.2) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[0] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[0] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_j = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_j;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S46>/If Action Subsystem' incorporates:
       *  ActionPort: '<S55>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S46>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S46>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S56>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_o);

      /* End of Outputs for SubSystem: '<S46>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S46>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S58>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_o, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S46>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S46>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S57>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[0],
        &rtb_Merge_o, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S46>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S46>/If' */

    /* Product: '<S17>/Weighting' incorporates:
     *  MinMax: '<S17>/andorMethod'
     */
    rtb_Weighting_f = fmin(rtb_Merge, rtb_Merge_o);

    /* If: '<S30>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[0] < -0.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[0] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_n = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_n;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem' incorporates:
       *  ActionPort: '<S36>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_c);

      /* End of Outputs for SubSystem: '<S30>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S37>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_c);

      /* End of Outputs for SubSystem: '<S30>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S39>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge_c, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S30>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S38>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge_c, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S30>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S30>/If' */

    /* Product: '<S18>/Weighting' incorporates:
     *  MinMax: '<S18>/andorMethod'
     */
    rtb_Weighting_i = fmin(rtb_Merge_c, rtb_Merge_m);

    /* Product: '<S19>/Weighting' incorporates:
     *  MinMax: '<S19>/andorMethod'
     */
    rtb_Weighting_l0 = fmin(rtb_Merge_c, rtb_Merge_j);

    /* Product: '<S20>/Weighting' incorporates:
     *  MinMax: '<S20>/andorMethod'
     */
    rtb_Weighting_p = fmin(rtb_Merge_c, rtb_Merge_o);

    /* If: '<S31>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[0] < 0.2) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[0] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[0] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_po = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_po;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S31>/If Action Subsystem' incorporates:
       *  ActionPort: '<S40>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_o2);

      /* End of Outputs for SubSystem: '<S31>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S31>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S41>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_o2);

      /* End of Outputs for SubSystem: '<S31>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S31>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S43>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge_o2, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S31>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S31>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S42>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[0],
        &rtb_Merge_o2, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S31>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S31>/If' */

    /* Product: '<S21>/Weighting' incorporates:
     *  MinMax: '<S21>/andorMethod'
     */
    rtb_Weighting_a = fmin(rtb_Merge_o2, rtb_Merge_m);

    /* Product: '<S22>/Weighting' incorporates:
     *  MinMax: '<S22>/andorMethod'
     */
    rtb_MathFunction_f = fmin(rtb_Merge_o2, rtb_Merge_j);

    /* MinMax: '<S23>/andorMethod' */
    rtb_Sum2 = fmin(rtb_Merge_o2, rtb_Merge_o);

    /* MinMax: '<S13>/AggMethod1' incorporates:
     *  Constant: '<S26>/mf1'
     *  Constant: '<S26>/mf2'
     *  Constant: '<S26>/mf3'
     *  MinMax: '<S15>/impMethod'
     *  MinMax: '<S16>/impMethod'
     *  MinMax: '<S17>/impMethod'
     *  MinMax: '<S18>/impMethod'
     *  MinMax: '<S19>/impMethod'
     *  MinMax: '<S20>/impMethod'
     *  MinMax: '<S21>/impMethod'
     *  MinMax: '<S22>/impMethod'
     *  MinMax: '<S23>/andorMethod'
     *  MinMax: '<S23>/impMethod'
     */
    for (i = 0; i < 101; i++) {
      rtb_AggMethod1[i] = fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmin
        (rtb_Weighting, DVR_Controller_ConstP.pooled12[i]), fmin
        (rtb_Weighting_cd, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_f, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_i, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_l0, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_p, DVR_Controller_ConstP.pooled14[i])), fmin
        (rtb_Weighting_a, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_MathFunction_f, DVR_Controller_ConstP.pooled14[i])), fmin(rtb_Sum2,
        DVR_Controller_ConstP.pooled14[i]));
    }

    /* End of MinMax: '<S13>/AggMethod1' */

    /* Sum: '<S14>/Sum1' */
    rtb_Sum1 = rtb_AggMethod1[0];
    for (i = 0; i < 100; i++) {
      rtb_Sum1 += rtb_AggMethod1[i + 1];
    }

    /* End of Sum: '<S14>/Sum1' */

    /* If: '<S14>/If' incorporates:
     *  Inport: '<S28>/u1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      rtAction = (int8_T)!(rtb_Sum1 <= 0.0);
      DVR_Controller_DW.If_ActiveSubsystem_or = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_or;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S14>/Action: One' incorporates:
       *  ActionPort: '<S27>/Action Port'
       */
      DVR_Controller_ActionOne(&rtb_Merge_e);

      /* End of Outputs for SubSystem: '<S14>/Action: One' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S14>/Action: u1' incorporates:
       *  ActionPort: '<S28>/Action Port'
       */
      rtb_Merge_e = rtb_Sum1;

      /* End of Outputs for SubSystem: '<S14>/Action: u1' */
      break;
    }

    /* End of If: '<S14>/If' */

    /* Switch: '<S13>/Switch' incorporates:
     *  Constant: '<S13>/MidRange'
     *  Constant: '<S13>/Zero'
     *  MinMax: '<S23>/andorMethod'
     *  Product: '<S14>/Averaging (COA)'
     *  RelationalOperator: '<S13>/Zero Firing Strength?'
     *  Sum: '<S13>/Total Firing Strength'
     */
    if (((((((((rtb_Weighting + rtb_Weighting_cd) + rtb_Weighting_f) +
              rtb_Weighting_i) + rtb_Weighting_l0) + rtb_Weighting_p) +
           rtb_Weighting_a) + rtb_MathFunction_f) + rtb_Sum2 > 0.0) >= 1) {
      /* Product: '<S14>/Product (COA)' incorporates:
       *  Constant: '<S14>/x data'
       */
      for (i = 0; i < 101; i++) {
        rtb_AggMethod1[i] *= DVR_Controller_ConstP.pooled15[i];
      }

      /* End of Product: '<S14>/Product (COA)' */

      /* Sum: '<S14>/Sum' */
      rtb_MathFunction_g = rtb_AggMethod1[0];
      for (i = 0; i < 100; i++) {
        rtb_MathFunction_g += rtb_AggMethod1[i + 1];
      }

      /* End of Sum: '<S14>/Sum' */
      rtb_MathFunction_g /= rtb_Merge_e;
    } else {
      rtb_MathFunction_g = 0.0;
    }

    /* End of Switch: '<S13>/Switch' */

    /* If: '<S75>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[1] < -1.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[1] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_ju = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_ju;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S75>/If Action Subsystem' incorporates:
       *  ActionPort: '<S78>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_b);

      /* End of Outputs for SubSystem: '<S75>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S75>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S79>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_b);

      /* End of Outputs for SubSystem: '<S75>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S75>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S81>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_b, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S75>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S75>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S80>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_b, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S75>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S75>/If' */

    /* If: '<S90>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[1] < -1.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[1] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_c = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_c;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S90>/If Action Subsystem' incorporates:
       *  ActionPort: '<S93>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_me);

      /* End of Outputs for SubSystem: '<S90>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S90>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S94>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_me);

      /* End of Outputs for SubSystem: '<S90>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S90>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S96>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_me, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S90>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S90>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S95>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_me, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S90>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S90>/If' */

    /* Product: '<S61>/Weighting' incorporates:
     *  MinMax: '<S61>/andorMethod'
     */
    rtb_MathFunction_f = fmin(rtb_Merge_b, rtb_Merge_me);

    /* If: '<S91>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[1] < -0.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[1] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_e = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_e;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem' incorporates:
       *  ActionPort: '<S97>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S91>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S98>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_p);

      /* End of Outputs for SubSystem: '<S91>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S100>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_p, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S91>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S91>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S99>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_p, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S91>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S91>/If' */

    /* Product: '<S62>/Weighting' incorporates:
     *  MinMax: '<S62>/andorMethod'
     */
    rtb_Weighting_a = fmin(rtb_Merge_b, rtb_Merge_p);

    /* If: '<S92>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[1] < 0.2) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[1] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[1] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_b = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_b;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S92>/If Action Subsystem' incorporates:
       *  ActionPort: '<S101>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S92>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S92>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S102>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_n);

      /* End of Outputs for SubSystem: '<S92>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S92>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S104>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_n, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S92>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S92>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S103>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[1],
        &rtb_Merge_n, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S92>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S92>/If' */

    /* Product: '<S63>/Weighting' incorporates:
     *  MinMax: '<S63>/andorMethod'
     */
    rtb_Weighting_p = fmin(rtb_Merge_b, rtb_Merge_n);

    /* If: '<S76>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[1] < -0.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[1] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_d = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_d;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S76>/If Action Subsystem' incorporates:
       *  ActionPort: '<S82>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_h);

      /* End of Outputs for SubSystem: '<S76>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S76>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S83>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_h);

      /* End of Outputs for SubSystem: '<S76>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S76>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S85>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_h, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S76>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S76>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S84>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_h, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S76>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S76>/If' */

    /* Product: '<S64>/Weighting' incorporates:
     *  MinMax: '<S64>/andorMethod'
     */
    rtb_Weighting_l0 = fmin(rtb_Merge_h, rtb_Merge_me);

    /* Product: '<S65>/Weighting' incorporates:
     *  MinMax: '<S65>/andorMethod'
     */
    rtb_Weighting_i = fmin(rtb_Merge_h, rtb_Merge_p);

    /* Product: '<S66>/Weighting' incorporates:
     *  MinMax: '<S66>/andorMethod'
     */
    rtb_Weighting_f = fmin(rtb_Merge_h, rtb_Merge_n);

    /* If: '<S77>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[1] < 0.2) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[1] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[1] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_f = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_f;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem' incorporates:
       *  ActionPort: '<S86>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_d);

      /* End of Outputs for SubSystem: '<S77>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S87>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_d);

      /* End of Outputs for SubSystem: '<S77>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S89>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_d, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S77>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S77>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S88>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[1],
        &rtb_Merge_d, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S77>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S77>/If' */

    /* Product: '<S67>/Weighting' incorporates:
     *  MinMax: '<S67>/andorMethod'
     */
    rtb_Weighting_cd = fmin(rtb_Merge_d, rtb_Merge_me);

    /* Product: '<S68>/Weighting' incorporates:
     *  MinMax: '<S68>/andorMethod'
     */
    rtb_Weighting = fmin(rtb_Merge_d, rtb_Merge_p);

    /* MinMax: '<S69>/andorMethod' */
    rtb_Sum2 = fmin(rtb_Merge_d, rtb_Merge_n);

    /* MinMax: '<S59>/AggMethod1' incorporates:
     *  Constant: '<S72>/mf1'
     *  Constant: '<S72>/mf2'
     *  Constant: '<S72>/mf3'
     *  MinMax: '<S61>/impMethod'
     *  MinMax: '<S62>/impMethod'
     *  MinMax: '<S63>/impMethod'
     *  MinMax: '<S64>/impMethod'
     *  MinMax: '<S65>/impMethod'
     *  MinMax: '<S66>/impMethod'
     *  MinMax: '<S67>/impMethod'
     *  MinMax: '<S68>/impMethod'
     *  MinMax: '<S69>/andorMethod'
     *  MinMax: '<S69>/impMethod'
     */
    for (i = 0; i < 101; i++) {
      rtb_AggMethod1[i] = fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmin
        (rtb_MathFunction_f, DVR_Controller_ConstP.pooled12[i]), fmin
        (rtb_Weighting_a, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_p, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_l0, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_i, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_f, DVR_Controller_ConstP.pooled14[i])), fmin
        (rtb_Weighting_cd, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting, DVR_Controller_ConstP.pooled14[i])), fmin(rtb_Sum2,
        DVR_Controller_ConstP.pooled14[i]));
    }

    /* End of MinMax: '<S59>/AggMethod1' */

    /* Sum: '<S60>/Sum1' */
    rtb_Sum1 = rtb_AggMethod1[0];
    for (i = 0; i < 100; i++) {
      rtb_Sum1 += rtb_AggMethod1[i + 1];
    }

    /* End of Sum: '<S60>/Sum1' */

    /* If: '<S60>/If' incorporates:
     *  Inport: '<S74>/u1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      rtAction = (int8_T)!(rtb_Sum1 <= 0.0);
      DVR_Controller_DW.If_ActiveSubsystem_a = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_a;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S60>/Action: One' incorporates:
       *  ActionPort: '<S73>/Action Port'
       */
      DVR_Controller_ActionOne(&rtb_Merge_b4);

      /* End of Outputs for SubSystem: '<S60>/Action: One' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S60>/Action: u1' incorporates:
       *  ActionPort: '<S74>/Action Port'
       */
      rtb_Merge_b4 = rtb_Sum1;

      /* End of Outputs for SubSystem: '<S60>/Action: u1' */
      break;
    }

    /* End of If: '<S60>/If' */

    /* Switch: '<S59>/Switch' incorporates:
     *  Constant: '<S59>/MidRange'
     *  Constant: '<S59>/Zero'
     *  MinMax: '<S69>/andorMethod'
     *  Product: '<S60>/Averaging (COA)'
     *  RelationalOperator: '<S59>/Zero Firing Strength?'
     *  Sum: '<S59>/Total Firing Strength'
     */
    if (((((((((rtb_MathFunction_f + rtb_Weighting_a) + rtb_Weighting_p) +
              rtb_Weighting_l0) + rtb_Weighting_i) + rtb_Weighting_f) +
           rtb_Weighting_cd) + rtb_Weighting) + rtb_Sum2 > 0.0) >= 1) {
      /* Product: '<S60>/Product (COA)' incorporates:
       *  Constant: '<S60>/x data'
       */
      for (i = 0; i < 101; i++) {
        rtb_AggMethod1[i] *= DVR_Controller_ConstP.pooled15[i];
      }

      /* End of Product: '<S60>/Product (COA)' */

      /* Sum: '<S60>/Sum' */
      rtb_Weighting = rtb_AggMethod1[0];
      for (i = 0; i < 100; i++) {
        rtb_Weighting += rtb_AggMethod1[i + 1];
      }

      /* End of Sum: '<S60>/Sum' */
      rtb_Sum1 = rtb_Weighting / rtb_Merge_b4;
    } else {
      rtb_Sum1 = 0.0;
    }

    /* End of Switch: '<S59>/Switch' */

    /* If: '<S121>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[2] < -1.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[2] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_fa = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_fa;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S121>/If Action Subsystem' incorporates:
       *  ActionPort: '<S124>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_jq);

      /* End of Outputs for SubSystem: '<S121>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S121>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S125>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_jq);

      /* End of Outputs for SubSystem: '<S121>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S121>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S127>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_jq, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S121>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S121>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S126>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_jq, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S121>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S121>/If' */

    /* If: '<S136>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[2] < -1.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[2] > -0.2)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] == -1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] < -1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_fi = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_fi;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S136>/If Action Subsystem' incorporates:
       *  ActionPort: '<S139>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_mi);

      /* End of Outputs for SubSystem: '<S136>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S136>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S140>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_mi);

      /* End of Outputs for SubSystem: '<S136>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S136>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S142>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_mi, -1.8, -1.0);

      /* End of Outputs for SubSystem: '<S136>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S136>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S141>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_mi, -1.0, -0.2);

      /* End of Outputs for SubSystem: '<S136>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S136>/If' */

    /* Product: '<S107>/Weighting' incorporates:
     *  MinMax: '<S107>/andorMethod'
     */
    rtb_MathFunction_f = fmin(rtb_Merge_jq, rtb_Merge_mi);

    /* If: '<S137>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[2] < -0.8) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[2] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_p3 = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_p3;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem' incorporates:
       *  ActionPort: '<S143>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_k);

      /* End of Outputs for SubSystem: '<S137>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S144>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_k);

      /* End of Outputs for SubSystem: '<S137>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S146>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_k, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S137>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S137>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S145>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_k, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S137>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S137>/If' */

    /* Product: '<S108>/Weighting' incorporates:
     *  MinMax: '<S108>/andorMethod'
     */
    rtb_Weighting_a = fmin(rtb_Merge_jq, rtb_Merge_k);

    /* If: '<S138>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay1_DSTATE[2] < 0.2) ||
          (DVR_Controller_DW.UnitDelay1_DSTATE[2] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay1_DSTATE[2] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_m = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_m;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem' incorporates:
       *  ActionPort: '<S147>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_mn);

      /* End of Outputs for SubSystem: '<S138>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S148>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_mn);

      /* End of Outputs for SubSystem: '<S138>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S150>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_mn, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S138>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S138>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S149>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay1_DSTATE[2],
        &rtb_Merge_mn, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S138>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S138>/If' */

    /* Product: '<S109>/Weighting' incorporates:
     *  MinMax: '<S109>/andorMethod'
     */
    rtb_Weighting_p = fmin(rtb_Merge_jq, rtb_Merge_mn);

    /* If: '<S122>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[2] < -0.8) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[2] > 0.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] == 0.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] < 0.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_l = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_l;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S122>/If Action Subsystem' incorporates:
       *  ActionPort: '<S128>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_ht);

      /* End of Outputs for SubSystem: '<S122>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S122>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S129>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_ht);

      /* End of Outputs for SubSystem: '<S122>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S122>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S131>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_ht, -0.8, 0.0);

      /* End of Outputs for SubSystem: '<S122>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S122>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S130>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_ht, 0.0, 0.8);

      /* End of Outputs for SubSystem: '<S122>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S122>/If' */

    /* Product: '<S110>/Weighting' incorporates:
     *  MinMax: '<S110>/andorMethod'
     */
    rtb_Weighting_l0 = fmin(rtb_Merge_ht, rtb_Merge_mi);

    /* Product: '<S111>/Weighting' incorporates:
     *  MinMax: '<S111>/andorMethod'
     */
    rtb_Weighting_i = fmin(rtb_Merge_ht, rtb_Merge_k);

    /* Product: '<S112>/Weighting' incorporates:
     *  MinMax: '<S112>/andorMethod'
     */
    rtb_Weighting_f = fmin(rtb_Merge_ht, rtb_Merge_mn);

    /* If: '<S123>/If' incorporates:
     *  UnitDelay: '<S1>/Unit Delay2'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      if ((DVR_Controller_DW.UnitDelay2_DSTATE[2] < 0.2) ||
          (DVR_Controller_DW.UnitDelay2_DSTATE[2] > 1.8)) {
        rtAction = 0;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] == 1.0) {
        rtAction = 1;
      } else if (DVR_Controller_DW.UnitDelay2_DSTATE[2] < 1.0) {
        rtAction = 2;
      } else {
        rtAction = 3;
      }

      DVR_Controller_DW.If_ActiveSubsystem_cw = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_cw;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S123>/If Action Subsystem' incorporates:
       *  ActionPort: '<S132>/Action Port'
       */
      DVR_Controlle_IfActionSubsystem(&rtb_Merge_oc);

      /* End of Outputs for SubSystem: '<S123>/If Action Subsystem' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S123>/If Action Subsystem1' incorporates:
       *  ActionPort: '<S133>/Action Port'
       */
      DVR_Controll_IfActionSubsystem1(&rtb_Merge_oc);

      /* End of Outputs for SubSystem: '<S123>/If Action Subsystem1' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<S123>/If Action Subsystem3' incorporates:
       *  ActionPort: '<S135>/Action Port'
       */
      DVR_Controll_IfActionSubsystem3(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_oc, 0.2, 1.0);

      /* End of Outputs for SubSystem: '<S123>/If Action Subsystem3' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<S123>/If Action Subsystem2' incorporates:
       *  ActionPort: '<S134>/Action Port'
       */
      DVR_Controll_IfActionSubsystem2(DVR_Controller_DW.UnitDelay2_DSTATE[2],
        &rtb_Merge_oc, 1.0, 1.8);

      /* End of Outputs for SubSystem: '<S123>/If Action Subsystem2' */
      break;
    }

    /* End of If: '<S123>/If' */

    /* Product: '<S113>/Weighting' incorporates:
     *  MinMax: '<S113>/andorMethod'
     */
    rtb_Weighting_cd = fmin(rtb_Merge_oc, rtb_Merge_mi);

    /* Product: '<S114>/Weighting' incorporates:
     *  MinMax: '<S114>/andorMethod'
     */
    rtb_Weighting = fmin(rtb_Merge_oc, rtb_Merge_k);

    /* MinMax: '<S115>/andorMethod' */
    rtb_Sum2 = fmin(rtb_Merge_oc, rtb_Merge_mn);

    /* MinMax: '<S105>/AggMethod1' incorporates:
     *  Constant: '<S118>/mf1'
     *  Constant: '<S118>/mf2'
     *  Constant: '<S118>/mf3'
     *  MinMax: '<S107>/impMethod'
     *  MinMax: '<S108>/impMethod'
     *  MinMax: '<S109>/impMethod'
     *  MinMax: '<S110>/impMethod'
     *  MinMax: '<S111>/impMethod'
     *  MinMax: '<S112>/impMethod'
     *  MinMax: '<S113>/impMethod'
     *  MinMax: '<S114>/impMethod'
     *  MinMax: '<S115>/impMethod'
     */
    for (i = 0; i < 101; i++) {
      rtb_AggMethod1[i] = fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmax(fmin
        (rtb_MathFunction_f, DVR_Controller_ConstP.pooled12[i]), fmin
        (rtb_Weighting_a, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_p, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_l0, DVR_Controller_ConstP.pooled12[i])), fmin
        (rtb_Weighting_i, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting_f, DVR_Controller_ConstP.pooled14[i])), fmin
        (rtb_Weighting_cd, DVR_Controller_ConstP.pooled13[i])), fmin
        (rtb_Weighting, DVR_Controller_ConstP.pooled14[i])), fmin(rtb_Sum2,
        DVR_Controller_ConstP.pooled14[i]));
    }

    /* End of MinMax: '<S105>/AggMethod1' */

    /* Sum: '<S106>/Sum1' */
    rtb_Sum1_j = rtb_AggMethod1[0];
    for (i = 0; i < 100; i++) {
      rtb_Sum1_j += rtb_AggMethod1[i + 1];
    }

    /* End of Sum: '<S106>/Sum1' */

    /* If: '<S106>/If' incorporates:
     *  Inport: '<S120>/u1'
     */
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      rtAction = (int8_T)!(rtb_Sum1_j <= 0.0);
      DVR_Controller_DW.If_ActiveSubsystem_cd = rtAction;
    } else {
      rtAction = DVR_Controller_DW.If_ActiveSubsystem_cd;
    }

    switch (rtAction) {
     case 0:
      /* Outputs for IfAction SubSystem: '<S106>/Action: One' incorporates:
       *  ActionPort: '<S119>/Action Port'
       */
      DVR_Controller_ActionOne(&rtb_Merge_htk);

      /* End of Outputs for SubSystem: '<S106>/Action: One' */
      break;

     case 1:
      /* Outputs for IfAction SubSystem: '<S106>/Action: u1' incorporates:
       *  ActionPort: '<S120>/Action Port'
       */
      rtb_Merge_htk = rtb_Sum1_j;

      /* End of Outputs for SubSystem: '<S106>/Action: u1' */
      break;
    }

    /* End of If: '<S106>/If' */

    /* Switch: '<S105>/Switch' incorporates:
     *  Constant: '<S105>/MidRange'
     *  Constant: '<S105>/Zero'
     *  Product: '<S106>/Averaging (COA)'
     *  RelationalOperator: '<S105>/Zero Firing Strength?'
     *  Sum: '<S105>/Total Firing Strength'
     */
    if (((((((((rtb_MathFunction_f + rtb_Weighting_a) + rtb_Weighting_p) +
              rtb_Weighting_l0) + rtb_Weighting_i) + rtb_Weighting_f) +
           rtb_Weighting_cd) + rtb_Weighting) + rtb_Sum2 > 0.0) >= 1) {
      /* Product: '<S106>/Product (COA)' incorporates:
       *  Constant: '<S106>/x data'
       */
      for (i = 0; i < 101; i++) {
        rtb_AggMethod1[i] *= DVR_Controller_ConstP.pooled15[i];
      }

      /* End of Product: '<S106>/Product (COA)' */

      /* Sum: '<S106>/Sum' */
      rtb_Weighting = rtb_AggMethod1[0];
      for (i = 0; i < 100; i++) {
        rtb_Weighting += rtb_AggMethod1[i + 1];
      }

      /* End of Sum: '<S106>/Sum' */
      rtb_Sum2 = rtb_Weighting / rtb_Merge_htk;
    } else {
      rtb_Sum2 = 0.0;
    }

    /* End of Switch: '<S105>/Switch' */

    /* Gain: '<S151>/1\ib1' incorporates:
     *  Constant: '<S151>/Constant1'
     *  Constant: '<S151>/Constant3'
     *  DigitalClock: '<S151>/Digital Clock'
     *  Math: '<S151>/Math Function'
     *  Sum: '<S151>/Add1'
     */
    rtb_uib1 = rt_remd_snf((((DVR_Controller_M->Timing.clockTick1+
      DVR_Controller_M->Timing.clockTickH1* 4294967296.0)) * 1.0E-5) +
      2.5000000000000005E-5, 0.0001) * 10000.0;

    /* Lookup: '<S151>/Lookup Table'
     * About '<S151>/Lookup Table':
     * Input0  Data Type:  Floating Point real_T
     * Output0 Data Type:  Floating Point real_T
     * Lookup Method: Linear_Endpoint
     *
     * XData is inlined and evenly spaced, so the algorithm only needs
     * the value of the first element, the last element, and the spacing.
     * For efficiency, XData is excluded from the generated code.
     * YData parameter uses the same data type and scaling as Output0
     */
    LookUpEven_real_T_real_T( &(rtb_LookupTable), DVR_Controller_ConstP.pooled20,
      rtb_uib1, 0.0, 2U, 0.5);

    /* Sum: '<S1>/Sum' incorporates:
     *  Constant: '<S151>/Constant2'
     *  Gain: '<S151>/1\ib1'
     *  Lookup: '<S151>/Lookup Table'
     *  Sum: '<S151>/Add3'
     */
    rtb_MathFunction_g = (rtb_LookupTable - 1.0) - rtb_MathFunction_g;

    /* Relay: '<S1>/Relay' incorporates:
     *  Relay: '<S1>/Relay1'
     */
    if (rtb_MathFunction_g >= 2.2204460492503131E-16) {
      DVR_Controller_DW.Relay_Mode = true;
      DVR_Controller_DW.Relay1_Mode = true;
    } else {
      if (rtb_MathFunction_g <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay_Mode = false;
      }

      if (rtb_MathFunction_g <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay1_Mode = false;
      }
    }

    rtb_Relay = DVR_Controller_DW.Relay_Mode;

    /* End of Relay: '<S1>/Relay' */

    /* Relay: '<S1>/Relay1' */
    rtb_Relay1 = !DVR_Controller_DW.Relay1_Mode;

    /* Gain: '<S152>/1\ib1' incorporates:
     *  Constant: '<S152>/Constant1'
     *  Constant: '<S152>/Constant3'
     *  DigitalClock: '<S152>/Digital Clock'
     *  Math: '<S152>/Math Function'
     *  Sum: '<S152>/Add1'
     */
    rtb_uib1_e = rt_remd_snf((((DVR_Controller_M->Timing.clockTick1+
      DVR_Controller_M->Timing.clockTickH1* 4294967296.0)) * 1.0E-5) +
      2.5000000000000005E-5, 0.0001) * 10000.0;

    /* Lookup: '<S152>/Lookup Table'
     * About '<S152>/Lookup Table':
     * Input0  Data Type:  Floating Point real_T
     * Output0 Data Type:  Floating Point real_T
     * Lookup Method: Linear_Endpoint
     *
     * XData is inlined and evenly spaced, so the algorithm only needs
     * the value of the first element, the last element, and the spacing.
     * For efficiency, XData is excluded from the generated code.
     * YData parameter uses the same data type and scaling as Output0
     */
    LookUpEven_real_T_real_T( &(rtb_LookupTable_j),
      DVR_Controller_ConstP.pooled20, rtb_uib1_e, 0.0, 2U, 0.5);

    /* Sum: '<S1>/Sum1' incorporates:
     *  Constant: '<S152>/Constant2'
     *  Gain: '<S152>/1\ib1'
     *  Lookup: '<S152>/Lookup Table'
     *  Sum: '<S152>/Add3'
     */
    rtb_Sum1 = (rtb_LookupTable_j - 1.0) - rtb_Sum1;

    /* Relay: '<S1>/Relay2' incorporates:
     *  Relay: '<S1>/Relay3'
     */
    if (rtb_Sum1 >= 2.2204460492503131E-16) {
      DVR_Controller_DW.Relay2_Mode = true;
      DVR_Controller_DW.Relay3_Mode = true;
    } else {
      if (rtb_Sum1 <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay2_Mode = false;
      }

      if (rtb_Sum1 <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay3_Mode = false;
      }
    }

    rtb_Relay2 = DVR_Controller_DW.Relay2_Mode;

    /* End of Relay: '<S1>/Relay2' */

    /* Relay: '<S1>/Relay3' */
    rtb_Relay3 = !DVR_Controller_DW.Relay3_Mode;

    /* Gain: '<S153>/1\ib1' incorporates:
     *  Constant: '<S153>/Constant1'
     *  Constant: '<S153>/Constant3'
     *  DigitalClock: '<S153>/Digital Clock'
     *  Math: '<S153>/Math Function'
     *  Sum: '<S153>/Add1'
     */
    rtb_uib1_g = rt_remd_snf((((DVR_Controller_M->Timing.clockTick1+
      DVR_Controller_M->Timing.clockTickH1* 4294967296.0)) * 1.0E-5) +
      2.5000000000000005E-5, 0.0001) * 10000.0;

    /* Lookup: '<S153>/Lookup Table'
     * About '<S153>/Lookup Table':
     * Input0  Data Type:  Floating Point real_T
     * Output0 Data Type:  Floating Point real_T
     * Lookup Method: Linear_Endpoint
     *
     * XData is inlined and evenly spaced, so the algorithm only needs
     * the value of the first element, the last element, and the spacing.
     * For efficiency, XData is excluded from the generated code.
     * YData parameter uses the same data type and scaling as Output0
     */
    LookUpEven_real_T_real_T( &(rtb_LookupTable_c),
      DVR_Controller_ConstP.pooled20, rtb_uib1_g, 0.0, 2U, 0.5);

    /* Sum: '<S1>/Sum2' incorporates:
     *  Constant: '<S153>/Constant2'
     *  Gain: '<S153>/1\ib1'
     *  Lookup: '<S153>/Lookup Table'
     *  Sum: '<S153>/Add3'
     */
    rtb_Sum2 = (rtb_LookupTable_c - 1.0) - rtb_Sum2;

    /* Relay: '<S1>/Relay4' incorporates:
     *  Relay: '<S1>/Relay5'
     */
    if (rtb_Sum2 >= 2.2204460492503131E-16) {
      DVR_Controller_DW.Relay4_Mode = true;
      DVR_Controller_DW.Relay5_Mode = true;
    } else {
      if (rtb_Sum2 <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay4_Mode = false;
      }

      if (rtb_Sum2 <= 2.2204460492503131E-16) {
        DVR_Controller_DW.Relay5_Mode = false;
      }
    }

    rtb_Relay4 = DVR_Controller_DW.Relay4_Mode;

    /* End of Relay: '<S1>/Relay4' */

    /* Relay: '<S1>/Relay5' */
    rtb_Relay5 = !DVR_Controller_DW.Relay5_Mode;

    /* Sum: '<S2>/Sum' incorporates:
     *  Gain: '<S2>/Gain'
     *  Gain: '<S2>/Gain1'
     *  Gain: '<S2>/Gain2'
     *  Inport: '<Root>/Ia'
     *  Inport: '<Root>/Ib'
     *  Inport: '<Root>/Ic'
     */
    rtb_Weighting = (0.8165 * DVR_Controller_U.Ia - 0.4082 * DVR_Controller_U.Ib)
      - 0.4082 * DVR_Controller_U.Ic;

    /* Sum: '<S2>/Sum1' incorporates:
     *  Gain: '<S2>/Gain3'
     *  Gain: '<S2>/Gain4'
     *  Inport: '<Root>/Ib'
     *  Inport: '<Root>/Ic'
     */
    rtb_Weighting_cd = 0.7071 * DVR_Controller_U.Ib - 0.7071 *
      DVR_Controller_U.Ic;

    /* Sum: '<Root>/Sum' incorporates:
     *  Constant: '<Root>/Constant'
     *  Inport: '<Root>/Vcap'
     */
    rtb_Sum_n = 120.0 - DVR_Controller_U.Vcap;

    /* Sum: '<Root>/Sum1' incorporates:
     *  DiscreteIntegrator: '<Root>/Discrete-Time Integrator'
     */
    DVR_Controller_B.Sum1 = rtb_Sum_n +
      DVR_Controller_DW.DiscreteTimeIntegrator_DSTATE;

    /* Sum: '<S6>/Sum' incorporates:
     *  Gain: '<S6>/Gain'
     *  Gain: '<S6>/Gain1'
     *  Gain: '<S6>/Gain2'
     *  Inport: '<Root>/Va'
     *  Inport: '<Root>/Vb'
     *  Inport: '<Root>/Vc'
     */
    DVR_Controller_B.Sum = (0.8165 * DVR_Controller_U.Va - 0.4082 *
      DVR_Controller_U.Vb) - 0.4082 * DVR_Controller_U.Vc;

    /* Sum: '<S6>/Sum1' incorporates:
     *  Gain: '<S6>/Gain3'
     *  Gain: '<S6>/Gain4'
     *  Inport: '<Root>/Vb'
     *  Inport: '<Root>/Vc'
     */
    DVR_Controller_B.Sum1_d = 0.7071 * DVR_Controller_U.Vb - 0.7071 *
      DVR_Controller_U.Vc;

    /* Sum: '<S3>/Sum1' incorporates:
     *  Math: '<S3>/Math Function'
     *  Math: '<S3>/Math Function1'
     */
    DVR_Controller_B.Sum1_m = DVR_Controller_B.Sum * DVR_Controller_B.Sum +
      DVR_Controller_B.Sum1_d * DVR_Controller_B.Sum1_d;
  }

  /* Product: '<S3>/Divide' incorporates:
   *  StateSpace: '<Root>/Analog Filter Design'
   *  Sum: '<S3>/Sum'
   */
  rtb_MathFunction_g = (DVR_Controller_X.AnalogFilterDesign_CSTATE[3] +
                        DVR_Controller_B.Sum1) / DVR_Controller_B.Sum1_m;

  /* Product: '<S3>/Product' */
  rtb_Weighting_f = rtb_MathFunction_g * DVR_Controller_B.Sum;

  /* Product: '<S3>/Product1' */
  rtb_MathFunction_g *= DVR_Controller_B.Sum1_d;

  /* Gain: '<S4>/Gain' */
  DVR_Controller_B.Gain = 0.8165 * rtb_Weighting_f;

  /* Sum: '<S4>/Sum' incorporates:
   *  Gain: '<S4>/Gain1'
   *  Gain: '<S4>/Gain3'
   */
  DVR_Controller_B.Sum_g = 0.7071 * rtb_MathFunction_g - 0.4082 *
    rtb_Weighting_f;

  /* Sum: '<S4>/Sum1' incorporates:
   *  Gain: '<S4>/Gain2'
   *  Gain: '<S4>/Gain4'
   */
  DVR_Controller_B.Sum1_n = (0.0 - 0.4082 * rtb_Weighting_f) - 0.7071 *
    rtb_MathFunction_g;
  if (rtmIsMajorTimeStep(DVR_Controller_M)) {
    /* UnitDelay: '<S4>/Unit Delay' */
    rtb_UnitDelay[0] = DVR_Controller_DW.UnitDelay_DSTATE_h[0];
    rtb_UnitDelay[1] = DVR_Controller_DW.UnitDelay_DSTATE_h[1];
    rtb_UnitDelay[2] = DVR_Controller_DW.UnitDelay_DSTATE_h[2];

    /* Sum: '<S5>/Sum' incorporates:
     *  Product: '<S5>/Product'
     *  Product: '<S5>/Product1'
     */
    DVR_Controller_B.Sum_b = DVR_Controller_B.Sum * rtb_Weighting +
      DVR_Controller_B.Sum1_d * rtb_Weighting_cd;
  }

  if (rtmIsMajorTimeStep(DVR_Controller_M)) {
    if (rtmIsMajorTimeStep(DVR_Controller_M)) {
      /* Update for UnitDelay: '<S1>/Unit Delay' */
      DVR_Controller_DW.UnitDelay_DSTATE[0] = rtb_Relay;
      DVR_Controller_DW.UnitDelay_DSTATE[1] = rtb_Relay1;
      DVR_Controller_DW.UnitDelay_DSTATE[2] = rtb_Relay2;
      DVR_Controller_DW.UnitDelay_DSTATE[3] = rtb_Relay3;
      DVR_Controller_DW.UnitDelay_DSTATE[4] = rtb_Relay4;
      DVR_Controller_DW.UnitDelay_DSTATE[5] = rtb_Relay5;

      /* Update for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
      DVR_Controller_DW.DiscreteTimeIntegrator_DSTATE += 1.0E-5 * rtb_Sum_n;

      /* Update for UnitDelay: '<S1>/Unit Delay2' */
      DVR_Controller_DW.UnitDelay2_DSTATE[0] = rtb_UnitDelay[0];
      DVR_Controller_DW.UnitDelay2_DSTATE[1] = rtb_UnitDelay[1];
      DVR_Controller_DW.UnitDelay2_DSTATE[2] = rtb_UnitDelay[2];

      /* Update for UnitDelay: '<S1>/Unit Delay1' incorporates:
       *  Update for Inport: '<Root>/Ima'
       *  Update for Inport: '<Root>/Imb'
       *  Update for Inport: '<Root>/Imc'
       */
      DVR_Controller_DW.UnitDelay1_DSTATE[0] = DVR_Controller_U.Ima;
      DVR_Controller_DW.UnitDelay1_DSTATE[1] = DVR_Controller_U.Imb;
      DVR_Controller_DW.UnitDelay1_DSTATE[2] = DVR_Controller_U.Imc;

      /* Update for UnitDelay: '<S4>/Unit Delay' */
      DVR_Controller_DW.UnitDelay_DSTATE_h[0] = DVR_Controller_B.Gain;
      DVR_Controller_DW.UnitDelay_DSTATE_h[1] = DVR_Controller_B.Sum_g;
      DVR_Controller_DW.UnitDelay_DSTATE_h[2] = DVR_Controller_B.Sum1_n;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(DVR_Controller_M)) {
    rt_ertODEUpdateContinuousStates(&DVR_Controller_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++DVR_Controller_M->Timing.clockTick0)) {
      ++DVR_Controller_M->Timing.clockTickH0;
    }

    DVR_Controller_M->Timing.t[0] = rtsiGetSolverStopTime
      (&DVR_Controller_M->solverInfo);

    {
      /* Update absolute timer for sample time: [1.0E-5s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 1.0E-5, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      DVR_Controller_M->Timing.clockTick1++;
      if (!DVR_Controller_M->Timing.clockTick1) {
        DVR_Controller_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void DVR_Controller_derivatives(void)
{
  XDot_DVR_Controller_T *_rtXdot;
  _rtXdot = ((XDot_DVR_Controller_T *) DVR_Controller_M->derivs);

  /* Derivatives for StateSpace: '<Root>/Analog Filter Design' */
  _rtXdot->AnalogFilterDesign_CSTATE[0] = 0.0;
  _rtXdot->AnalogFilterDesign_CSTATE[1] = 0.0;
  _rtXdot->AnalogFilterDesign_CSTATE[2] = 0.0;
  _rtXdot->AnalogFilterDesign_CSTATE[3] = 0.0;
  _rtXdot->AnalogFilterDesign_CSTATE[0] += -36.955181300451471 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[0];
  _rtXdot->AnalogFilterDesign_CSTATE[0] += -20.0 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[1];
  _rtXdot->AnalogFilterDesign_CSTATE[1] += 20.0 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[0];
  _rtXdot->AnalogFilterDesign_CSTATE[2] += 20.0 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[1];
  _rtXdot->AnalogFilterDesign_CSTATE[2] += -15.307337294603588 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[2];
  _rtXdot->AnalogFilterDesign_CSTATE[2] += -20.0 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[3];
  _rtXdot->AnalogFilterDesign_CSTATE[3] += 20.0 *
    DVR_Controller_X.AnalogFilterDesign_CSTATE[2];
  _rtXdot->AnalogFilterDesign_CSTATE[0] += 20.0 * DVR_Controller_B.Sum_b;
}

/* Model initialize function */
void DVR_Controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)DVR_Controller_M, 0,
                sizeof(RT_MODEL_DVR_Controller_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&DVR_Controller_M->solverInfo,
                          &DVR_Controller_M->Timing.simTimeStep);
    rtsiSetTPtr(&DVR_Controller_M->solverInfo, &rtmGetTPtr(DVR_Controller_M));
    rtsiSetStepSizePtr(&DVR_Controller_M->solverInfo,
                       &DVR_Controller_M->Timing.stepSize0);
    rtsiSetdXPtr(&DVR_Controller_M->solverInfo, &DVR_Controller_M->derivs);
    rtsiSetContStatesPtr(&DVR_Controller_M->solverInfo, (real_T **)
                         &DVR_Controller_M->contStates);
    rtsiSetNumContStatesPtr(&DVR_Controller_M->solverInfo,
      &DVR_Controller_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&DVR_Controller_M->solverInfo,
      &DVR_Controller_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&DVR_Controller_M->solverInfo,
      &DVR_Controller_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&DVR_Controller_M->solverInfo,
      &DVR_Controller_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&DVR_Controller_M->solverInfo, (&rtmGetErrorStatus
      (DVR_Controller_M)));
    rtsiSetRTModelPtr(&DVR_Controller_M->solverInfo, DVR_Controller_M);
  }

  rtsiSetSimTimeStep(&DVR_Controller_M->solverInfo, MAJOR_TIME_STEP);
  DVR_Controller_M->intgData.y = DVR_Controller_M->odeY;
  DVR_Controller_M->intgData.f[0] = DVR_Controller_M->odeF[0];
  DVR_Controller_M->intgData.f[1] = DVR_Controller_M->odeF[1];
  DVR_Controller_M->intgData.f[2] = DVR_Controller_M->odeF[2];
  DVR_Controller_M->contStates = ((X_DVR_Controller_T *) &DVR_Controller_X);
  rtsiSetSolverData(&DVR_Controller_M->solverInfo, (void *)
                    &DVR_Controller_M->intgData);
  rtsiSetSolverName(&DVR_Controller_M->solverInfo,"ode3");
  rtmSetTPtr(DVR_Controller_M, &DVR_Controller_M->Timing.tArray[0]);
  DVR_Controller_M->Timing.stepSize0 = 1.0E-5;

  /* block I/O */
  (void) memset(((void *) &DVR_Controller_B), 0,
                sizeof(B_DVR_Controller_T));

  /* states (continuous) */
  {
    (void) memset((void *)&DVR_Controller_X, 0,
                  sizeof(X_DVR_Controller_T));
  }

  /* states (dwork) */
  (void) memset((void *)&DVR_Controller_DW, 0,
                sizeof(DW_DVR_Controller_T));

  /* external inputs */
  (void)memset((void *)&DVR_Controller_U, 0, sizeof(ExtU_DVR_Controller_T));

  /* external outputs */
  (void) memset((void *)&DVR_Controller_Y, 0,
                sizeof(ExtY_DVR_Controller_T));

  /* Start for If: '<S29>/If' */
  DVR_Controller_DW.If_ActiveSubsystem = -1;

  /* Start for If: '<S44>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_p = -1;

  /* Start for If: '<S45>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_o = -1;

  /* Start for If: '<S46>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_j = -1;

  /* Start for If: '<S30>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_n = -1;

  /* Start for If: '<S31>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_po = -1;

  /* Start for If: '<S14>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_or = -1;

  /* Start for If: '<S75>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_ju = -1;

  /* Start for If: '<S90>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_c = -1;

  /* Start for If: '<S91>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_e = -1;

  /* Start for If: '<S92>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_b = -1;

  /* Start for If: '<S76>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_d = -1;

  /* Start for If: '<S77>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_f = -1;

  /* Start for If: '<S60>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_a = -1;

  /* Start for If: '<S121>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_fa = -1;

  /* Start for If: '<S136>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_fi = -1;

  /* Start for If: '<S137>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_p3 = -1;

  /* Start for If: '<S138>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_m = -1;

  /* Start for If: '<S122>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_l = -1;

  /* Start for If: '<S123>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_cw = -1;

  /* Start for If: '<S106>/If' */
  DVR_Controller_DW.If_ActiveSubsystem_cd = -1;

  /* InitializeConditions for StateSpace: '<Root>/Analog Filter Design' */
  DVR_Controller_X.AnalogFilterDesign_CSTATE[0] = 0.0;
  DVR_Controller_X.AnalogFilterDesign_CSTATE[1] = 0.0;
  DVR_Controller_X.AnalogFilterDesign_CSTATE[2] = 0.0;
  DVR_Controller_X.AnalogFilterDesign_CSTATE[3] = 0.0;
}

/* Model terminate function */
void DVR_Controller_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
