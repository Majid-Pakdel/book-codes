/*
 * File: DVR_Controller.h
 *
 * Code generated for Simulink model 'DVR_Controller'.
 *
 * Model version                  : 1.23
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Tue Jul 09 11:13:45 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_DVR_Controller_h_
#define RTW_HEADER_DVR_Controller_h_
#include <float.h>
#include <math.h>
#include <string.h>
#ifndef DVR_Controller_COMMON_INCLUDES_
# define DVR_Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* DVR_Controller_COMMON_INCLUDES_ */

#include "DVR_Controller_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Sum1;                         /* '<Root>/Sum1' */
  real_T Sum;                          /* '<S6>/Sum' */
  real_T Sum1_d;                       /* '<S6>/Sum1' */
  real_T Sum1_m;                       /* '<S3>/Sum1' */
  real_T Gain;                         /* '<S4>/Gain' */
  real_T Sum_g;                        /* '<S4>/Sum' */
  real_T Sum1_n;                       /* '<S4>/Sum1' */
  real_T Sum_b;                        /* '<S5>/Sum' */
} B_DVR_Controller_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay_DSTATE[6];          /* '<S1>/Unit Delay' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<Root>/Discrete-Time Integrator' */
  real_T UnitDelay2_DSTATE[3];         /* '<S1>/Unit Delay2' */
  real_T UnitDelay1_DSTATE[3];         /* '<S1>/Unit Delay1' */
  real_T UnitDelay_DSTATE_h[3];        /* '<S4>/Unit Delay' */
  int8_T If_ActiveSubsystem;           /* '<S29>/If' */
  int8_T If_ActiveSubsystem_p;         /* '<S44>/If' */
  int8_T If_ActiveSubsystem_o;         /* '<S45>/If' */
  int8_T If_ActiveSubsystem_j;         /* '<S46>/If' */
  int8_T If_ActiveSubsystem_n;         /* '<S30>/If' */
  int8_T If_ActiveSubsystem_po;        /* '<S31>/If' */
  int8_T If_ActiveSubsystem_or;        /* '<S14>/If' */
  int8_T If_ActiveSubsystem_ju;        /* '<S75>/If' */
  int8_T If_ActiveSubsystem_c;         /* '<S90>/If' */
  int8_T If_ActiveSubsystem_e;         /* '<S91>/If' */
  int8_T If_ActiveSubsystem_b;         /* '<S92>/If' */
  int8_T If_ActiveSubsystem_d;         /* '<S76>/If' */
  int8_T If_ActiveSubsystem_f;         /* '<S77>/If' */
  int8_T If_ActiveSubsystem_a;         /* '<S60>/If' */
  int8_T If_ActiveSubsystem_fa;        /* '<S121>/If' */
  int8_T If_ActiveSubsystem_fi;        /* '<S136>/If' */
  int8_T If_ActiveSubsystem_p3;        /* '<S137>/If' */
  int8_T If_ActiveSubsystem_m;         /* '<S138>/If' */
  int8_T If_ActiveSubsystem_l;         /* '<S122>/If' */
  int8_T If_ActiveSubsystem_cw;        /* '<S123>/If' */
  int8_T If_ActiveSubsystem_cd;        /* '<S106>/If' */
  boolean_T Relay_Mode;                /* '<S1>/Relay' */
  boolean_T Relay1_Mode;               /* '<S1>/Relay1' */
  boolean_T Relay2_Mode;               /* '<S1>/Relay2' */
  boolean_T Relay3_Mode;               /* '<S1>/Relay3' */
  boolean_T Relay4_Mode;               /* '<S1>/Relay4' */
  boolean_T Relay5_Mode;               /* '<S1>/Relay5' */
} DW_DVR_Controller_T;

/* Continuous states (auto storage) */
typedef struct {
  real_T AnalogFilterDesign_CSTATE[4]; /* '<Root>/Analog Filter Design' */
} X_DVR_Controller_T;

/* State derivatives (auto storage) */
typedef struct {
  real_T AnalogFilterDesign_CSTATE[4]; /* '<Root>/Analog Filter Design' */
} XDot_DVR_Controller_T;

/* State disabled  */
typedef struct {
  boolean_T AnalogFilterDesign_CSTATE[4];/* '<Root>/Analog Filter Design' */
} XDis_DVR_Controller_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Constant parameters (auto storage) */
typedef struct {
  /* Pooled Parameter (Expression: trimf(linspace(fis.output(1).range(1),fis.output(1).range(2),101),fis.output(1).mf(1).params))
   * Referenced by:
   *   '<S26>/mf1'
   *   '<S72>/mf1'
   *   '<S118>/mf1'
   */
  real_T pooled12[101];

  /* Pooled Parameter (Expression: trimf(linspace(fis.output(1).range(1),fis.output(1).range(2),101),fis.output(1).mf(2).params))
   * Referenced by:
   *   '<S26>/mf2'
   *   '<S72>/mf2'
   *   '<S118>/mf2'
   */
  real_T pooled13[101];

  /* Pooled Parameter (Expression: trimf(linspace(fis.output(1).range(1),fis.output(1).range(2),101),fis.output(1).mf(3).params))
   * Referenced by:
   *   '<S26>/mf3'
   *   '<S72>/mf3'
   *   '<S118>/mf3'
   */
  real_T pooled14[101];

  /* Pooled Parameter (Expression: Xdata)
   * Referenced by:
   *   '<S14>/x data'
   *   '<S60>/x data'
   *   '<S106>/x data'
   */
  real_T pooled15[101];

  /* Pooled Parameter (Expression: [0 2 0])
   * Referenced by:
   *   '<S151>/Lookup Table'
   *   '<S152>/Lookup Table'
   *   '<S153>/Lookup Table'
   */
  real_T pooled20[3];
} ConstP_DVR_Controller_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Vcap;                         /* '<Root>/Vcap' */
  real_T Va;                           /* '<Root>/Va' */
  real_T Vb;                           /* '<Root>/Vb' */
  real_T Vc;                           /* '<Root>/Vc' */
  real_T Ia;                           /* '<Root>/Ia' */
  real_T Ib;                           /* '<Root>/Ib' */
  real_T Ic;                           /* '<Root>/Ic' */
  real_T Ima;                          /* '<Root>/Ima' */
  real_T Imb;                          /* '<Root>/Imb' */
  real_T Imc;                          /* '<Root>/Imc' */
} ExtU_DVR_Controller_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T GaH;                          /* '<Root>/GaH' */
  real_T GaL;                          /* '<Root>/GaL' */
  real_T GbH;                          /* '<Root>/GbH' */
  real_T GbL;                          /* '<Root>/GbL' */
  real_T GcH;                          /* '<Root>/GcH' */
  real_T GcL;                          /* '<Root>/GcL' */
} ExtY_DVR_Controller_T;

/* Real-time Model Data Structure */
struct tag_RTM_DVR_Controller_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_DVR_Controller_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T blkStateChange;
  real_T odeY[4];
  real_T odeF[3][4];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block signals (auto storage) */
extern B_DVR_Controller_T DVR_Controller_B;

/* Continuous states (auto storage) */
extern X_DVR_Controller_T DVR_Controller_X;

/* Block states (auto storage) */
extern DW_DVR_Controller_T DVR_Controller_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_DVR_Controller_T DVR_Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_DVR_Controller_T DVR_Controller_Y;

/* Constant parameters (auto storage) */
extern const ConstP_DVR_Controller_T DVR_Controller_ConstP;

/* Model entry point functions */
extern void DVR_Controller_initialize(void);
extern void DVR_Controller_step(void);
extern void DVR_Controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_DVR_Controller_T *const DVR_Controller_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Scope' : Unused code path elimination
 * Block '<S5>/Gain' : Unused code path elimination
 * Block '<S5>/Product2' : Unused code path elimination
 * Block '<S5>/Product3' : Unused code path elimination
 * Block '<S5>/Sum1' : Unused code path elimination
 * Block '<Root>/Scope' : Unused code path elimination
 * Block '<Root>/Scope10' : Unused code path elimination
 * Block '<S24>/DataConv' : Eliminate redundant data type conversion
 * Block '<S25>/DataConv' : Eliminate redundant data type conversion
 * Block '<S70>/DataConv' : Eliminate redundant data type conversion
 * Block '<S71>/DataConv' : Eliminate redundant data type conversion
 * Block '<S116>/DataConv' : Eliminate redundant data type conversion
 * Block '<S117>/DataConv' : Eliminate redundant data type conversion
 * Block '<Root>/Gain' : Eliminated nontunable gain of 1
 * Block '<Root>/Gain1' : Eliminated nontunable gain of 1
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'DVR_Controller'
 * '<S1>'   : 'DVR_Controller/Fuzzy Control'
 * '<S2>'   : 'DVR_Controller/I-Clark'
 * '<S3>'   : 'DVR_Controller/I-Comp-Clark'
 * '<S4>'   : 'DVR_Controller/Inv-I-Clark'
 * '<S5>'   : 'DVR_Controller/P-Q'
 * '<S6>'   : 'DVR_Controller/V-Clark'
 * '<S7>'   : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller'
 * '<S8>'   : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1'
 * '<S9>'   : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2'
 * '<S10>'  : 'DVR_Controller/Fuzzy Control/Triangle Generator'
 * '<S11>'  : 'DVR_Controller/Fuzzy Control/Triangle Generator1'
 * '<S12>'  : 'DVR_Controller/Fuzzy Control/Triangle Generator2'
 * '<S13>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard'
 * '<S14>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Defuzzification1'
 * '<S15>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule1'
 * '<S16>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule2'
 * '<S17>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule3'
 * '<S18>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule4'
 * '<S19>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule5'
 * '<S20>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule6'
 * '<S21>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule7'
 * '<S22>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule8'
 * '<S23>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Rule9'
 * '<S24>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1'
 * '<S25>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2'
 * '<S26>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/output1'
 * '<S27>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Defuzzification1/Action: One'
 * '<S28>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/Defuzzification1/Action: u1'
 * '<S29>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf1'
 * '<S30>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf2'
 * '<S31>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf3'
 * '<S32>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf1/If Action Subsystem'
 * '<S33>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf1/If Action Subsystem1'
 * '<S34>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf1/If Action Subsystem2'
 * '<S35>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf1/If Action Subsystem3'
 * '<S36>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf2/If Action Subsystem'
 * '<S37>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf2/If Action Subsystem1'
 * '<S38>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf2/If Action Subsystem2'
 * '<S39>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf2/If Action Subsystem3'
 * '<S40>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf3/If Action Subsystem'
 * '<S41>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf3/If Action Subsystem1'
 * '<S42>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf3/If Action Subsystem2'
 * '<S43>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input1/mf3/If Action Subsystem3'
 * '<S44>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf1'
 * '<S45>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf2'
 * '<S46>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf3'
 * '<S47>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf1/If Action Subsystem'
 * '<S48>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf1/If Action Subsystem1'
 * '<S49>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf1/If Action Subsystem2'
 * '<S50>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf1/If Action Subsystem3'
 * '<S51>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf2/If Action Subsystem'
 * '<S52>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf2/If Action Subsystem1'
 * '<S53>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf2/If Action Subsystem2'
 * '<S54>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf2/If Action Subsystem3'
 * '<S55>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf3/If Action Subsystem'
 * '<S56>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf3/If Action Subsystem1'
 * '<S57>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf3/If Action Subsystem2'
 * '<S58>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller/FIS Wizard/input2/mf3/If Action Subsystem3'
 * '<S59>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard'
 * '<S60>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Defuzzification1'
 * '<S61>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule1'
 * '<S62>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule2'
 * '<S63>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule3'
 * '<S64>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule4'
 * '<S65>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule5'
 * '<S66>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule6'
 * '<S67>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule7'
 * '<S68>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule8'
 * '<S69>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Rule9'
 * '<S70>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1'
 * '<S71>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2'
 * '<S72>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/output1'
 * '<S73>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Defuzzification1/Action: One'
 * '<S74>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/Defuzzification1/Action: u1'
 * '<S75>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf1'
 * '<S76>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf2'
 * '<S77>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf3'
 * '<S78>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf1/If Action Subsystem'
 * '<S79>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf1/If Action Subsystem1'
 * '<S80>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf1/If Action Subsystem2'
 * '<S81>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf1/If Action Subsystem3'
 * '<S82>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf2/If Action Subsystem'
 * '<S83>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf2/If Action Subsystem1'
 * '<S84>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf2/If Action Subsystem2'
 * '<S85>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf2/If Action Subsystem3'
 * '<S86>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf3/If Action Subsystem'
 * '<S87>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf3/If Action Subsystem1'
 * '<S88>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf3/If Action Subsystem2'
 * '<S89>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input1/mf3/If Action Subsystem3'
 * '<S90>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf1'
 * '<S91>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf2'
 * '<S92>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf3'
 * '<S93>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf1/If Action Subsystem'
 * '<S94>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf1/If Action Subsystem1'
 * '<S95>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf1/If Action Subsystem2'
 * '<S96>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf1/If Action Subsystem3'
 * '<S97>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf2/If Action Subsystem'
 * '<S98>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf2/If Action Subsystem1'
 * '<S99>'  : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf2/If Action Subsystem2'
 * '<S100>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf2/If Action Subsystem3'
 * '<S101>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf3/If Action Subsystem'
 * '<S102>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf3/If Action Subsystem1'
 * '<S103>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf3/If Action Subsystem2'
 * '<S104>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller1/FIS Wizard/input2/mf3/If Action Subsystem3'
 * '<S105>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard'
 * '<S106>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Defuzzification1'
 * '<S107>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule1'
 * '<S108>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule2'
 * '<S109>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule3'
 * '<S110>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule4'
 * '<S111>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule5'
 * '<S112>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule6'
 * '<S113>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule7'
 * '<S114>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule8'
 * '<S115>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Rule9'
 * '<S116>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1'
 * '<S117>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2'
 * '<S118>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/output1'
 * '<S119>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Defuzzification1/Action: One'
 * '<S120>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/Defuzzification1/Action: u1'
 * '<S121>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf1'
 * '<S122>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf2'
 * '<S123>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf3'
 * '<S124>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf1/If Action Subsystem'
 * '<S125>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf1/If Action Subsystem1'
 * '<S126>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf1/If Action Subsystem2'
 * '<S127>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf1/If Action Subsystem3'
 * '<S128>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf2/If Action Subsystem'
 * '<S129>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf2/If Action Subsystem1'
 * '<S130>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf2/If Action Subsystem2'
 * '<S131>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf2/If Action Subsystem3'
 * '<S132>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf3/If Action Subsystem'
 * '<S133>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf3/If Action Subsystem1'
 * '<S134>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf3/If Action Subsystem2'
 * '<S135>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input1/mf3/If Action Subsystem3'
 * '<S136>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf1'
 * '<S137>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf2'
 * '<S138>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf3'
 * '<S139>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf1/If Action Subsystem'
 * '<S140>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf1/If Action Subsystem1'
 * '<S141>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf1/If Action Subsystem2'
 * '<S142>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf1/If Action Subsystem3'
 * '<S143>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf2/If Action Subsystem'
 * '<S144>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf2/If Action Subsystem1'
 * '<S145>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf2/If Action Subsystem2'
 * '<S146>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf2/If Action Subsystem3'
 * '<S147>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf3/If Action Subsystem'
 * '<S148>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf3/If Action Subsystem1'
 * '<S149>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf3/If Action Subsystem2'
 * '<S150>' : 'DVR_Controller/Fuzzy Control/Fuzzy Logic  Controller2/FIS Wizard/input2/mf3/If Action Subsystem3'
 * '<S151>' : 'DVR_Controller/Fuzzy Control/Triangle Generator/Model'
 * '<S152>' : 'DVR_Controller/Fuzzy Control/Triangle Generator1/Model'
 * '<S153>' : 'DVR_Controller/Fuzzy Control/Triangle Generator2/Model'
 */
#endif                                 /* RTW_HEADER_DVR_Controller_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
